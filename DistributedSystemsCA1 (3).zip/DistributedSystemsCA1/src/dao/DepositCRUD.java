package dao;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import entities.Deposit;




@Path("/sampleserviceDBCRUD")
public class DepositCRUD {
	
	private static Map<String, Deposit> deposits = new HashMap<String, Deposit>();
	
	static {
		
		Deposit deposit1 = new Deposit();
		deposit1.setId(1);
		deposit1.setContent("Fabrizio");
		deposits.put(Integer.toString(deposit1.getId()), deposit1);

		Deposit deposit2 = new Deposit();
		deposit2.setId(2); 
		deposit2.setContent("Justin");
		deposits.put(Integer.toString(deposit2.getId()), deposit2);

      
    }

	@GET
    @Path("/hello")
    @Produces("text/plain")
    public String hello(){
        return "Hello World";    
    }
	
	@GET
    @Path("/helloworld")
    @Produces("text/plain")
    public String helloWorld(){
        return "Hello World New";    
    }
	
	@GET
    @Path("/echo/{message}")
    @Produces("text/plain")
    public String echo(@PathParam("message")String message){
        return message;  
    }
	
	@GET
    @Path("/newEcho/{message}")
    @Produces("text/plain")
    public String newEcho(@PathParam("message")String message){
        return message;  
    }

	
	@GET
    @Path("/Deposits")
    @Produces("application/xml")
    public List<Deposit> listDeposits(){
        return new ArrayList<Deposit>(deposits.values());
    }
	
	@GET
    @Path("/Deposit/{Depositid}")
    @Produces("application/xml")
    public Deposit getDeposit(@PathParam("Depositid")String DepositId){
		return deposits.get(DepositId);		
    }
	
	@POST
	@Path("/createxml")
    @Consumes("application/xml")
    public String addDeposit(Deposit Deposit){
		
		return "Deposit added " +Deposit.getDepositName();		
    }
	
	@POST
	@Path("/createjson")
    @Consumes("application/json")
    public String addJSONDeposit(Deposit Deposit){
		return "Deposit added " +Deposit.getDepositName();		
    }
	
	@GET
    @Path("/json/Deposits/")
    @Produces("application/json")
    public List<Deposit> listDepositsJSON(){
		return new ArrayList<Deposit>(deposits.values());
    }

	@GET
    @Path("/json/Deposit/{Depositid}")
    @Produces("application/json")
    public Deposit getDepositJSON(@PathParam("Depositid")String DepositId){
		return deposits.get(DepositId);		
    }
	
	@GET
    @Path("/Depositsxmlfromdb")
    @Produces("application/xml")
    public List<Deposit> getDepositsFromDB(){
        DepositDAO dao = new DepositDAO();
        return dao.getAllDeposits();
    }
	
	@GET
    @Path("/Depositsjsonfromdb")
    @Produces("application/json")
    public List<Deposit> getJSONDepositsFromDB(){
        DepositDAO dao = new DepositDAO();
        return dao.getAllDeposits();
    }
	
	@GET
    @Path("/jsonDB/Deposit/{DepositName}")
    @Produces("application/json")
    public Deposit getDepositByNameFromDBJSON(@PathParam("DepositName")String DepositName){
		DepositDAO dao = new DepositDAO();
		return dao.getDepositByName(DepositName);		
    }
	
	@GET
    @Path("/DepositfromDBXML/{DepositName}")
    @Produces("application/xml")
    public Deposit getDepositByNameFromDBXML(@PathParam("DepositName")String DepositName){
		DepositDAO dao = new DepositDAO();
		return dao.getDepositByName(DepositName);	
    }
	
	@POST
	@Path("/newDeposit")
    @Consumes("application/json")
    public String addDepositToDBJSON(Deposit Deposit){
		DepositDAO dao = new DepositDAO();
		dao.persist(Deposit);
		return "Deposit added to DB from JSON Param "+Deposit.getDepositName();	
    }
	
	@PUT
    @Path("/updateDeposit/")
    @Produces("application/json")
    public Deposit updateDeposit(Deposit Deposit){
		DepositDAO dao = new DepositDAO();
		return dao.merge(Deposit);	
    }
	
	@DELETE
    @Path("/deleteDeposit/{DepositName}")
    @Produces("text/plain")
    public String deleteDeposit(@PathParam("DepositName")String DepositName){
		DepositDAO dao = new DepositDAO();
		Deposit emp = dao.getDepositByName(DepositName);
		dao.remove(emp);	
		return "Deposit "+emp+" deleted";
    }
	
	
}
