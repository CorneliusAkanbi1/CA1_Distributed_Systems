package dao;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import entities.Deposit;
import entities.Loan;
import entities.Loan;




@Path("/sampleserviceDBCRUD")
public class LoanCRUD {
	
	private static Map<String, Loan> loans = new HashMap<String, Loan>();
	
	static {
		
		Loan loan1 = new Loan();
		loan1.setId(1); 
		loan1.setDescription("funds");
		List<Deposit> deposits1 = new ArrayList<>();
		
		deposits1.add(new Deposit("3000")); 
		loan1.setDeposits(deposits1);
		loans.put(String.valueOf(loan1.getId()), loan1);

		Loan loan2 = new Loan();
		loan2.setId(2); 
		loan2.setDescription("funds");
		
		List<Deposit> deposits2 = new ArrayList<>();
		deposits2.add(new Deposit("2000"));
		loan2.setDeposits(deposits2);
		loans.put(String.valueOf(loan2.getId()), loan2);

        
    }

	@GET
    @Path("/hello")
    @Produces("text/plain")
    public String hello(){
        return "Hello World";    
    }
	
	@GET
    @Path("/helloworld")
    @Produces("text/plain")
    public String helloWorld(){
        return "Hello World New";    
    }
	
	@GET
    @Path("/echo/{message}")
    @Produces("text/plain")
    public String echo(@PathParam("message")String message){
        return message;  
    }
	
	@GET
    @Path("/newEcho/{message}")
    @Produces("text/plain")
    public String newEcho(@PathParam("message")String message){
        return message;  
    }

	
	@GET
    @Path("/Loans")
    @Produces("application/xml")
    public List<Loan> listLoans(){
        return new ArrayList<Loan>(loans.values());
    }
	
	@GET
    @Path("/Loan/{Loanid}")
    @Produces("application/xml")
    public Loan getLoan(@PathParam("Loanid")String LoanId){
		return loans.get(LoanId);		
    }
	
	@POST
	@Path("/createxml")
    @Consumes("application/xml")
    public String addLoan(Loan Loan){
		
		return "Loan added " +Loan.getLoanName();		
    }
	
	@POST
	@Path("/createjson")
    @Consumes("application/json")
    public String addJSONLoan(Loan Loan){
		return "Loan added " +Loan.getLoanName();		
    }
	
	@GET
    @Path("/json/Loans/")
    @Produces("application/json")
    public List<Loan> listLoansJSON(){
		return new ArrayList<Loan>(loans.values());
    }

	@GET
    @Path("/json/Loan/{Loanid}")
    @Produces("application/json")
    public Loan getLoanJSON(@PathParam("Loanid")String LoanId){
		return loans.get(LoanId);		
    }
	
	@GET
    @Path("/Loansxmlfromdb")
    @Produces("application/xml")
    public List<Loan> getLoansFromDB(){
        LoanDAO dao = new LoanDAO();
        return dao.getAllLoans();
    }
	
	@GET
    @Path("/Loansjsonfromdb")
    @Produces("application/json")
    public List<Loan> getJSONLoansFromDB(){
        LoanDAO dao = new LoanDAO();
        return dao.getAllLoans();
    }
	
	@GET
    @Path("/jsonDB/Loan/{LoanName}")
    @Produces("application/json")
    public Loan getLoanByNameFromDBJSON(@PathParam("LoanName")String LoanName){
		LoanDAO dao = new LoanDAO();
		return dao.getLoanByName(LoanName);		
    }
	
	@GET
    @Path("/LoanfromDBXML/{LoanName}")
    @Produces("application/xml")
    public Loan getLoanByNameFromDBXML(@PathParam("LoanName")String LoanName){
		LoanDAO dao = new LoanDAO();
		return dao.getLoanByName(LoanName);	
    }
	
	@POST
	@Path("/newLoan")
    @Consumes("application/json")
    public String addLoanToDBJSON(Loan Loan){
		LoanDAO dao = new LoanDAO();
		dao.persist(Loan);
		return "Loan added to DB from JSON Param "+Loan.getLoanName();	
    }
	
	@PUT
    @Path("/updateLoan/")
    @Produces("application/json")
    public Loan updateLoan(Loan Loan){
		LoanDAO dao = new LoanDAO();
		return dao.merge(Loan);	
    }
	
	@DELETE
    @Path("/deleteLoan/{LoanName}")
    @Produces("text/plain")
    public String deleteLoan(@PathParam("LoanName")String LoanName){
		LoanDAO dao = new LoanDAO();
		Loan emp = dao.getLoanByName(LoanName);
		dao.remove(emp);	
		return "Loan "+emp+" deleted";
    }
	
	
}
