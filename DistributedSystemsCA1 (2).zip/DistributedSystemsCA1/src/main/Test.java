package main;

import java.util.ArrayList;
import java.util.List;

import dao.DepositDAO;
import dao.LoanDAO;
import dao.CustomerDAO;
import entities.Deposit;
import entities.Loan;
import entities.Customer;

public class Test {
	
	
	public Test() {
		CustomerDAO cDAO = new CustomerDAO();
		LoanDAO lDAO = new LoanDAO();
		DepositDAO dDAO = new DepositDAO();
		
		//Add comments
		Deposit c1 = new Deposit("1000");
		Deposit c2 = new Deposit("2000");
		Deposit c3 = new Deposit("3000");
		dDAO.persist(c1);
		dDAO.persist(c2);
		dDAO.persist(c3);
		
		List<Deposit> deposits = new ArrayList<Deposit>();
		deposits.add(c1);
		deposits.add(c2);
		deposits.add(c3);
		//Add Profile
		Loan loan = new Loan("all deposits", deposits);
		lDAO.persist(loan);
		
		//Add Subscriber
		Customer customer = new Customer("Tom","Jerry", loan );
		cDAO.persist(customer);
		
		//View all subscribers (here I've accessed all objects through the subscriber)
		ArrayList<Customer> customers = (ArrayList<Customer>) cDAO.getAllCustomers();
		for(Customer c : customers) {
			System.out.println("Subscriber object username is "+c.getUsername());
			System.out.println("Subscriber's Profile says "+ c.getLoan().getDescription());
			//Note I've made an Eagar Fetch on the Comments List in Profile to enable this
			System.out.println("Subscriber's profile's first comment is "+c.getLoan().getComments().get(0).getContent());
		}
		
		//Update username using merge
		customer.setUsername("STEVO");
		cDAO.merge(customer);	
		
		//remove the last comment
		dDAO.remove(c3);
		
		//Get subscriber by username, print their password
		System.out.println(cDAO.getCustomerByUsername("STEVO").getPassword());
		
	}
	
	public static void main(String[] args) {
		new Test();
	}

}