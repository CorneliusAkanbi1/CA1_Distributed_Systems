package com.example.dit;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.example.dit.model.Deposit;


@Path("/sampleserviceDBCRUD")
public class SampleServiceDBCRUD {
	
	private static Map<String, Deposit> deposits = new HashMap<String, Deposit>();
	
	static {
		
        Deposit deposit1 = new Deposit();
        deposit1.setId("1");
        deposit1.setContent("3000);
        deposits.put(deposit1.getDepositId(), deposit1);
        
        Deposit deposit2 = new Deposit();
        deposit2.setId("2");
        deposit2.setContent("2000");
        deposits.put(deposit2.getDepositId(), deposit2);
        
    }

	@GET
    @Path("/hello")
    @Produces("text/plain")
    public String hello(){
        return "Hello World";    
    }
	
	@GET
    @Path("/helloworld")
    @Produces("text/plain")
    public String helloWorld(){
        return "Hello World New";    
    }
	
	@GET
    @Path("/echo/{message}")
    @Produces("text/plain")
    public String echo(@PathParam("message")String message){
        return message;  
    }
	
	@GET
    @Path("/newEcho/{message}")
    @Produces("text/plain")
    public String newEcho(@PathParam("message")String message){
        return message;  
    }

	
	@GET
    @Path("/deposits")
    @Produces("application/xml")
    public List<Deposit> listDeposits(){
        return new ArrayList<Deposit>(deposits.values());
    }
	
	@GET
    @Path("/deposit/{depositid}")
    @Produces("application/xml")
    public Deposit getDeposit(@PathParam("depositid")String depositId){
		return deposits.get(depositId);		
    }
	
	@POST
	@Path("/createxml")
    @Consumes("application/xml")
    public String addDeposit(Deposit deposit){
		
		return "Deposit added " +deposit.getDepositName();		
    }
	
	@POST
	@Path("/createjson")
    @Consumes("application/json")
    public String addJSONDeposit(Deposit deposit){
		return "Deposit added " +deposit.getDepositName();		
    }
	
	@GET
    @Path("/json/deposits/")
    @Produces("application/json")
    public List<Deposit> listDepositsJSON(){
		return new ArrayList<Deposit>(deposits.values());
    }

	@GET
    @Path("/json/deposit/{depositid}")
    @Produces("application/json")
    public Deposit getDepositJSON(@PathParam("depositid")String depositId){
		return deposits.get(depositId);		
    }
	
	@GET
    @Path("/depositsxmlfromdb")
    @Produces("application/xml")
    public List<Deposit> getDepositsFromDB(){
        DepositDAO dao = new DepositDAO();
        return dao.getAllDeposits();
    }
	
	@GET
    @Path("/depositsjsonfromdb")
    @Produces("application/json")
    public List<Deposit> getJSONDepositsFromDB(){
        DepositDAO dao = new DepositDAO();
        return dao.getAllDeposits();
    }
	
	@GET
    @Path("/jsonDB/deposit/{depositName}")
    @Produces("application/json")
    public Deposit getDepositByNameFromDBJSON(@PathParam("depositName")String depositName){
		DepositDAO dao = new DepositDAO();
		return dao.getDepositByName(depositName);		
    }
	
	@GET
    @Path("/depositfromDBXML/{depositName}")
    @Produces("application/xml")
    public Deposit getDepositByNameFromDBXML(@PathParam("depositName")String depositName){
		DepositDAO dao = new DepositDAO();
		return dao.getDepositByName(depositName);	
    }
	
	@POST
	@Path("/newDeposit")
    @Consumes("application/json")
    public String addDepositToDBJSON(Deposit deposit){
		DepositDAO dao = new DepositDAO();
		dao.persist(deposit);
		return "Deposit added to DB from JSON Param "+deposit.getDepositName();	
    }
	
	@PUT
    @Path("/updateDeposit/")
    @Produces("application/json")
    public Deposit updateDeposit(Deposit deposit){
		DepositDAO dao = new DepositDAO();
		return dao.merge(deposit);	
    }
	
	@DELETE
    @Path("/deleteDeposit/{depositName}")
    @Produces("text/plain")
    public String deleteDeposit(@PathParam("depositName")String depositName){
		DepositDAO dao = new DepositDAO();
		Deposit emp = dao.getDepositByName(depositName);
		dao.removeDeposit(emp);	
		return "Deposit "+emp+" deleted";
    }
	
	
}
