package com.example.dit;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.example.dit.model.Loan;


@Path("/sampleserviceDBCRUD")
public class SampleServiceDBCRUD {
	
	private static Map<String, Loan> loans = new HashMap<String, Loan>();
	
	static {
		
        Loan loan1 = new Loan();
        loan1.setId("1");
        loan1.setDescription("DD");
        loan1.setDeposits("3000");
        loans.put(loan1.getLoanId(), loan1);
        
        Loan loan2 = new Loan();
        loan2.setId("2");
        loan2.setDescription("DD");
        loan2.setDeposits("2000");
        loans.put(loan2.getLoanId(), loan2);
        
    }

	@GET
    @Path("/hello")
    @Produces("text/plain")
    public String hello(){
        return "Hello World";    
    }
	
	@GET
    @Path("/helloworld")
    @Produces("text/plain")
    public String helloWorld(){
        return "Hello World New";    
    }
	
	@GET
    @Path("/echo/{message}")
    @Produces("text/plain")
    public String echo(@PathParam("message")String message){
        return message;  
    }
	
	@GET
    @Path("/newEcho/{message}")
    @Produces("text/plain")
    public String newEcho(@PathParam("message")String message){
        return message;  
    }

	
	@GET
    @Path("/loans")
    @Produces("application/xml")
    public List<Loan> listLoans(){
        return new ArrayList<Loan>(loans.values());
    }
	
	@GET
    @Path("/loan/{loanid}")
    @Produces("application/xml")
    public Loan getLoan(@PathParam("loanid")String loanId){
		return loans.get(loanId);		
    }
	
	@POST
	@Path("/createxml")
    @Consumes("application/xml")
    public String addLoan(Loan loan){
		
		return "Loan added " +loan.getLoanName();		
    }
	
	@POST
	@Path("/createjson")
    @Consumes("application/json")
    public String addJSONLoan(Loan loan){
		return "Loan added " +loan.getLoanName();		
    }
	
	@GET
    @Path("/json/loans/")
    @Produces("application/json")
    public List<Loan> listLoansJSON(){
		return new ArrayList<Loan>(loans.values());
    }

	@GET
    @Path("/json/loan/{loanid}")
    @Produces("application/json")
    public Loan getLoanJSON(@PathParam("loanid")String loanId){
		return loans.get(loanId);		
    }
	
	@GET
    @Path("/loansxmlfromdb")
    @Produces("application/xml")
    public List<Loan> getLoansFromDB(){
        LoanDAO dao = new LoanDAO();
        return dao.getAllLoans();
    }
	
	@GET
    @Path("/loansjsonfromdb")
    @Produces("application/json")
    public List<Loan> getJSONLoansFromDB(){
        LoanDAO dao = new LoanDAO();
        return dao.getAllLoans();
    }
	
	@GET
    @Path("/jsonDB/loan/{loanName}")
    @Produces("application/json")
    public Loan getDescriptionFromDBJSON(@PathParam("loanName")String loanName){
		LoanDAO dao = new LoanDAO();
		return dao.getDescription(loanName);		
    }
	
	@GET
    @Path("/loanfromDBXML/{loanName}")
    @Produces("application/xml")
    public Loan getDescriptionFromDBXML(@PathParam("loanName")String loanName){
		LoanDAO dao = new LoanDAO();
		return dao.getDescription(loanName);	
    }
	
	@POST
	@Path("/newLoan")
    @Consumes("application/json")
    public String addLoanToDBJSON(Loan loan){
		LoanDAO dao = new LoanDAO();
		dao.persist(loan);
		return "Loan added to DB from JSON Param "+loan.getLoanName();	
    }
	
	@PUT
    @Path("/updateLoan/")
    @Produces("application/json")
    public Loan updateLoan(Loan loan){
		LoanDAO dao = new LoanDAO();
		return dao.merge(loan);	
    }
	
	@DELETE
    @Path("/deleteLoan/{loanName}")
    @Produces("text/plain")
    public String deleteLoan(@PathParam("loanName")String loanName){
		LoanDAO dao = new LoanDAO();
		Loan emp = dao.getDescription(loanName);
		dao.removeLoan(emp);	
		return "Loan "+emp+" deleted";
    }
	
	
}

