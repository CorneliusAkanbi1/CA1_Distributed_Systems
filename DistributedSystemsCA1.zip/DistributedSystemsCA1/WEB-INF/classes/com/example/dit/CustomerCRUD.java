package dao;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import entities.Customer;
import entities.Loan;



@Path("/sampleserviceDBCRUD")
public class CustomerCRUD {
	
	private static Map<String, Customer> customers = new HashMap<String, Customer>();
	
	static {
		
		Customer customer1 = new Customer();
		customer1.setId(1); 
		customer1.setUsername("Fabrizio");
		customer1.setPassword("Software Engineer");

		Loan loan1 = new Loan();
		loan1.setDescription("funds"); 
		customer1.setLoan(loan1);

		customers.put(Integer.toString(customer1.getId()), customer1); // Convert int ID to String

		Customer customer2 = new Customer();
		customer2.setId(2); 
		customer2.setUsername("Justin");
		customer2.setPassword("Business Analyst");

		Loan loan2 = new Loan();
		loan2.setDescription("funds"); 
		customer2.setLoan(loan2);

		customers.put(Integer.toString(customer2.getId()), customer2); // Convert int ID to String



        
    }

	@GET
    @Path("/hello")
    @Produces("text/plain")
    public String hello(){
        return "Hello World";    
    }
	
	@GET
    @Path("/helloworld")
    @Produces("text/plain")
    public String helloWorld(){
        return "Hello World New";    
    }
	
	@GET
    @Path("/echo/{message}")
    @Produces("text/plain")
    public String echo(@PathParam("message")String message){
        return message;  
    }
	
	@GET
    @Path("/newEcho/{message}")
    @Produces("text/plain")
    public String newEcho(@PathParam("message")String message){
        return message;  
    }

	
	@GET
    @Path("/Customers")
    @Produces("application/xml")
    public List<Customer> listCustomers(){
        return new ArrayList<Customer>(customers.values());
    }
	
	@GET
    @Path("/Customer/{Customerid}")
    @Produces("application/xml")
    public Customer getCustomer(@PathParam("Customerid")String CustomerId){
		return customers.get(CustomerId);		
    }
	
	@POST
	@Path("/createxml")
    @Consumes("application/xml")
    public String addCustomer(Customer Customer){
		
		return "Customer added " +Customer.getUsername();		
    }
	
	@POST
	@Path("/createjson")
    @Consumes("application/json")
    public String addJSONCustomer(Customer Customer){
		return "Customer added " +Customer.getUsername();		
    }
	
	@GET
    @Path("/json/Customers/")
    @Produces("application/json")
    public List<Customer> listCustomersJSON(){
		return new ArrayList<Customer>(customers.values());
    }

	@GET
    @Path("/json/Customer/{Customerid}")
    @Produces("application/json")
    public Customer getCustomerJSON(@PathParam("Customerid")String CustomerId){
		return customers.get(CustomerId);		
    }
	
	@GET
    @Path("/Customersxmlfromdb")
    @Produces("application/xml")
    public List<Customer> getCustomersFromDB(){
        CustomerDAO dao = new CustomerDAO();
        return dao.getAllCustomers();
    }
	
	@GET
    @Path("/Customersjsonfromdb")
    @Produces("application/json")
    public List<Customer> getJSONCustomersFromDB(){
        CustomerDAO dao = new CustomerDAO();
        return dao.getAllCustomers();
    }
	
	@GET
    @Path("/jsonDB/Customer/{CustomerName}")
    @Produces("application/json")
    public Customer getCustomerByNameFromDBJSON(@PathParam("CustomerName")String CustomerName){
		CustomerDAO dao = new CustomerDAO();
		return dao.getCustomerByUsername(CustomerName);		
    }
	
	@GET
    @Path("/CustomerfromDBXML/{CustomerName}")
    @Produces("application/xml")
    public Customer getCustomerByNameFromDBXML(@PathParam("CustomerName")String CustomerName){
		CustomerDAO dao = new CustomerDAO();
		return dao.getCustomerByUsername(CustomerName);	
    }
	
	@POST
	@Path("/newCustomer")
    @Consumes("application/json")
    public String addCustomerToDBJSON(Customer Customer){
		CustomerDAO dao = new CustomerDAO();
		dao.persist(Customer);
		return "Customer added to DB from JSON Param "+Customer.getUsername();	
    }
	
	@PUT
    @Path("/updateCustomer/")
    @Produces("application/json")
    public Customer updateCustomer(Customer Customer){
		CustomerDAO dao = new CustomerDAO();
		return dao.merge(Customer);	
    }
	
	@DELETE
    @Path("/deleteCustomer/{CustomerName}")
    @Produces("text/plain")
    public String deleteCustomer(@PathParam("CustomerName")String CustomerName){
		CustomerDAO dao = new CustomerDAO();
		Customer emp = dao.getCustomerByUsername(CustomerName);
		dao.remove(emp);	
		return "Customer "+emp+" deleted";
    }
	
	
}
